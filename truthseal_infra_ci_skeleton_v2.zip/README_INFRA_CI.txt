
TruthSeal Infrastructure & CI/CD Skeleton v2
---------------------------------------------
This package contains the base infrastructure setup for GitHub Actions + Terraform + Docker + Ledger automation.

Directories:
- .github/workflows/ : CI/CD YAML pipelines
- infra/terraform/   : Terraform infrastructure templates
- infra/scripts/     : Ledger stamping and verification scripts
- docker/            : Base Dockerfile for builds

Usage:
1. Extract the contents into your GitHub repository root.
2. Commit & push.
3. Workflows will appear in GitHub → Actions tab.
